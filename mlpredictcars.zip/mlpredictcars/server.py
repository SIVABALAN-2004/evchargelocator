from flask import Flask, request, jsonify
import mysql.connector

app = Flask(__name__)

# MySQL Connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="sanjay9865",  # Change this to your MySQL password
    database="evlocator"  # ✅ Correct database
)

@app.route("/update_car_count", methods=["POST"])
def update_car_count():
    try:
        data = request.json
        station_id = data.get("id")
        car_number = data.get("car_number")

        if not station_id or car_number is None:
            return jsonify({"error": "⚠️ ID and car number are required"}), 400

        sql = "UPDATE charging_stations SET cars = %s WHERE id = %s"
        
        with db.cursor() as cursor:
            cursor.execute(sql, (car_number, station_id))
            db.commit()
            
            if cursor.rowcount == 0:
                return jsonify({"error": "⚠️ No station found with the given ID"}), 404

        return jsonify({"message": f"✅ Car count updated for station ID {station_id}", "id": station_id})

    except mysql.connector.Error as err:
        return jsonify({"error": f"❌ Database error: {err}"}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000, debug=True)
