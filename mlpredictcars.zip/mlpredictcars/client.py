from ultralytics import YOLO
import cv2
import yt_dlp
import time
import requests
import numpy as np
from datetime import datetime

# 🚗 Client ID (Each client must have a unique ID)
CLIENT_ID = 1  # Change this for different clients

# 🎥 YouTube Live Stream URL (Replace with your stream link)
youtube_url = "https://www.youtube.com/watch?v=mwN6l3O1MNI"

# 🌐 Flask API Endpoint
server_url = "http://localhost:3000/update_car_count"

# ⏱ Time variables
capture_interval = 30  # Send data every 30 seconds
last_sent_time = time.time()

# 🔍 Load YOLOv8 model
model = YOLO("yolov8n.pt")  # Ensure you have the YOLOv8 model

# 📡 Function to get YouTube live stream URL
def get_live_stream_url(youtube_url):
    ydl_opts = {'format': 'best[ext=mp4]', 'quiet': True, 'noplaylist': True}
    for _ in range(3):  # Try 3 times before giving up
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(youtube_url, download=False)
                return info.get('url', None)
        except Exception as e:
            print(f"❌ Error fetching stream URL: {e}. Retrying...")
            time.sleep(5)
    return None

# 🎥 Open the live stream using OpenCV
def open_video_stream():
    video_url = get_live_stream_url(youtube_url)
    if not video_url:
        print("❌ Error: Could not extract live stream URL. Exiting...")
        exit()
    
    cap = cv2.VideoCapture(video_url)
    if not cap.isOpened():
        print("❌ Error: Could not open YouTube live stream. Exiting...")
        exit()
    
    return cap

cap = open_video_stream()  # Get video capture object

# 🚀 Main loop
while True:
    ret, frame = cap.read()
    
    if not ret:
        print("⚠️ Error: Failed to fetch frame. Attempting to reconnect...")
        cap = open_video_stream()  # Try reconnecting
        continue

    # 🏎️ Object detection using YOLOv8
    results = model(frame)
    car_count = sum(1 for result in results for box in result.boxes if int(box.cls) == 2)  # Class ID 2 (car)

    # ⏳ Send data every 30 seconds
    current_time = time.time()
    if current_time - last_sent_time >= capture_interval:
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        data = {"id": CLIENT_ID, "car_number": car_count, "timestamp": timestamp}

        # 🌍 Send data to the server
        try:
            response = requests.post(server_url, json=data, timeout=5)
            if response.status_code == 200:
                print(f"✅ Client {CLIENT_ID}: Sent car count ({car_count}) at {timestamp}")
            else:
                print(f"⚠️ Client {CLIENT_ID}: Server error -", response.text)
        except requests.exceptions.RequestException as e:
            print(f"❌ Client {CLIENT_ID}: Failed to send data -", e)
        
        last_sent_time = current_time  # Update last sent time

    # 🖥️ Display the frame (Optional)
    cv2.imshow("Live Stream with Car Detection", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        print("🛑 Stopping...")
        break  # Stop if 'q' is pressed

# 🛠️ Release resources
cap.release()
cv2.destroyAllWindows()
